# KinyaFlix AI — Android + Website starter

This is a source-code starter, not a finished commercial streaming service.

## Honest status
- Source scaffold generated: yes.
- Build/test performed here: no.
- APK produced: no.
- AI models/model weights bundled: no.
- Licensed catalogue/payment system: not included.
- Kinyarwanda ASR, translation, and TTS quality: not yet validated.

## Structure
- `android/`: Kotlin + Jetpack Compose + Media3 Android client.
- `web/`: React + Vite upload/translation-job prototype.
- `backend/`: FastAPI upload/job API with explicit unconfigured AI pipeline.
- `docs/`: architecture and model integration notes.

Only process media you own or are authorized to use. This project does not bypass DRM.

## Run backend (Python 3.11+)
```bash
cd backend
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
Open `http://localhost:8000/docs`.

## Run website (Node.js 20+)
```bash
cd web
npm install
npm run dev
```
Set `VITE_API_BASE=http://localhost:8000` in `web/.env.local` if needed.

## Android
Open `android/` in Android Studio with Android SDK 35 installed and run the `app` configuration. It selects local videos and plays them with Media3. The subtitle picker is currently a placeholder; SRT rendering is not yet implemented.

## AI pipeline
The backend intentionally returns `not_configured` rather than pretending to generate translations. A real implementation needs timestamped speech recognition, Kinyarwanda translation, subtitle review, Kinyarwanda-capable speech synthesis, and audio alignment. See `docs/MODEL_INTEGRATION.md`.

## Offline-first design
Store authorized downloaded media and completed language assets in app-private storage. Select models only after checking Kinyarwanda task support, licensing, on-device memory/latency/battery, and native-speaker quality. Cloud processing should be optional and disclosed. Use WorkManager for long jobs and checksums/versioning for model downloads.

## Production checklist
Add authentication, database-backed jobs, secure object storage, signed URLs, resumable uploads, malware scanning, rate limits, HTTPS, privacy policy, rights/takedown workflow, provider-approved catalogue playback, native-speaker evaluation, and automated tests.
