package com.kinyaflix.ai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF100E18)
private val Violet = Color(0xFFB69CFF)
private val Panel = Color(0xFF201C2B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KinyaFlixScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KinyaFlixScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    var note by remember { mutableStateOf("Choose a video you are authorized to use.") }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            note = "Video selected. AI translation models are not configured in this starter."
        }
    }
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            subtitleUri = uri
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            note = "Subtitle selected. Timed subtitle rendering is not implemented yet."
        }
    }
    val player = remember(videoUri) {
        videoUri?.let { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(it)); prepare() } }
    }
    DisposableEffect(player) { onDispose { player?.release() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Ink, topBar = {
            TopAppBar(title = { Column {
                Text("KinyaFlix AI", style = MaterialTheme.typography.titleLarge)
                Text("FILMS. YOUR LANGUAGE.", fontSize = 9.sp, color = Violet, letterSpacing = 2.sp)
            } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White))
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Murakaza neza!", style = MaterialTheme.typography.headlineMedium, color = Violet)
                Text("Reba filimi kandi utegure ibisobanuro mu Kinyarwanda.", color = Color.LightGray)
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.Movie, null, tint = Violet, modifier = Modifier.size(32.dp))
                        Text("Your videos", style = MaterialTheme.typography.titleLarge)
                        Button(onClick = { videoPicker.launch(arrayOf("video/*", "audio/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Choose video")
                        }
                        OutlinedButton(onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/plain", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.ClosedCaption, null); Spacer(Modifier.width(8.dp)); Text("Choose subtitle file (.srt)")
                        }
                    }
                }
                if (player != null) {
                    AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                        modifier = Modifier.fillMaxWidth().height(230.dp).background(Color.Black))
                } else {
                    Box(Modifier.fillMaxWidth().height(170.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                        Text("Your movie will appear here", color = Color.LightGray)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Kinyarwanda AI", style = MaterialTheme.typography.titleMedium, color = Violet)
                        Text("Subtitles and AI dubbing are planned, but model adapters are not configured yet.", color = Color.LightGray)
                        Text(note, style = MaterialTheme.typography.bodySmall)
                        subtitleUri?.let { Text("Subtitle selected: ${it.lastPathSegment ?: "subtitle file"}", color = Violet, fontSize = 12.sp) }
                    }
                }
                Text("Use only media you own or have permission to process. This starter does not bypass DRM.", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
