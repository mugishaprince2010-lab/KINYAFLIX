# Model integration checklist

Verify before selecting any model:
- Kinyarwanda is explicitly supported and tested for the task.
- License permits intended use and redistribution.
- Offline inference fits target phone memory, CPU/GPU/NPU, storage, latency and battery.
- Timestamped speech recognition and punctuation are usable.
- Kinyarwanda voice output is intelligible and natural to native speakers.
- Model downloads are checksum-verified and versioned.
- Users are told before cloud processing.

Implement adapters:
- `SpeechRecognizer.transcribe(audio) -> segments`
- `Translator.translate(segments, target_language="rw") -> translated_segments`
- `SpeechSynthesizer.synthesize(text, voice_id) -> audio`
- `Aligner.align(audio, segments) -> timed_audio_or_segments`

Do not clone actors' voices or imply actor-voice replication without explicit rights and consent.
