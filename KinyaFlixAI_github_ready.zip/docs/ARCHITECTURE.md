# Architecture

Android: local playback, file selection, offline assets, language preferences.
Web: upload authorized media, preview job status, future catalogue UI.
API: upload validation, media metadata, job orchestration, subtitle/audio asset serving.
Worker (future): isolated media processing; never pass uploaded filenames to shell commands.

Suggested job states: `uploaded -> queued -> transcribing -> translating -> synthesizing -> reviewing -> ready | failed`.

Store segment timestamps in milliseconds. Translated speech may not fit source timing; permit reflow and audio alignment.

Licensed catalogue access requires contracts and provider-approved playback integrations. Do not scrape or bypass DRM.
