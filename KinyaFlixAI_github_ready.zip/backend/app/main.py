from pathlib import Path
from uuid import uuid4
import json

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from .pipeline import run_translation_job

BASE = Path(__file__).resolve().parents[1]
UPLOAD_DIR = BASE / "data" / "uploads"
JOB_DIR = BASE / "data" / "jobs"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
JOB_DIR.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD_BYTES = 1_000_000_000
ALLOWED_EXTENSIONS = {".mp4", ".mkv", ".mov", ".webm", ".mp3", ".wav", ".m4a"}

app = FastAPI(title="KinyaFlix AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"],
)

class JobRequest(BaseModel):
    media_id: str
    target_language: str = "rw"
    output_subtitles: bool = True
    output_dubbing: bool = True

@app.get("/health")
def health():
    return {"status": "ok", "ai_pipeline": "adapter_not_configured"}

@app.post("/api/media")
async def upload_media(file: UploadFile = File(...), rights_confirmed: bool = Form(...)):
    if not rights_confirmed:
        raise HTTPException(status_code=400, detail="Confirm you have rights to process this media.")
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail=f"Unsupported file type: {ext or 'unknown'}")
    media_id = uuid4().hex
    destination = UPLOAD_DIR / f"{media_id}{ext}"
    size = 0
    try:
        with destination.open("wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    raise HTTPException(status_code=413, detail="Upload exceeds development limit.")
                out.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    metadata = {"media_id": media_id, "original_name": Path(file.filename or "upload").name,
                "size_bytes": size, "extension": ext, "status": "uploaded"}
    (JOB_DIR / f"media_{media_id}.json").write_text(json.dumps(metadata, indent=2))
    return metadata

@app.post("/api/jobs")
def create_job(request: JobRequest):
    if not (JOB_DIR / f"media_{request.media_id}.json").exists():
        raise HTTPException(status_code=404, detail="Unknown media_id")
    if request.target_language != "rw":
        raise HTTPException(status_code=400, detail="This starter currently targets Kinyarwanda (rw).")
    result = run_translation_job(request.media_id, request.output_subtitles, request.output_dubbing)
    job_id = uuid4().hex
    job = {"job_id": job_id, "media_id": request.media_id, **result}
    (JOB_DIR / f"job_{job_id}.json").write_text(json.dumps(job, indent=2))
    return job

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    path = JOB_DIR / f"job_{job_id}.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Unknown job_id")
    return json.loads(path.read_text())

@app.get("/api/media/{media_id}")
def get_media(media_id: str):
    matches = list(UPLOAD_DIR.glob(f"{media_id}.*"))
    if not matches:
        raise HTTPException(status_code=404, detail="Media not found")
    return FileResponse(matches[0], filename=matches[0].name)

@app.get("/api/subtitles/{media_id}")
def get_subtitles(media_id: str):
    path = JOB_DIR / f"subtitles_{media_id}.srt"
    if not path.exists():
        raise HTTPException(status_code=404, detail="No subtitle file generated yet.")
    return FileResponse(path, media_type="application/x-subrip", filename=path.name)
