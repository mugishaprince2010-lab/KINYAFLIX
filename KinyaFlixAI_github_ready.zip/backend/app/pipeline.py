"""
AI adapter boundary. No AI models are bundled, so this module must not claim
that translation or dubbing has happened. Integrate validated ASR, translation,
TTS and alignment adapters before processing real media.
"""

def run_translation_job(media_id: str, output_subtitles: bool, output_dubbing: bool) -> dict:
    requested = []
    if output_subtitles:
        requested.append("subtitles")
    if output_dubbing:
        requested.append("dubbing")
    return {
        "status": "not_configured",
        "message": "AI models are not configured. Add and validate Kinyarwanda speech recognition, translation, TTS, and timing adapters first.",
        "outputs": {"requested": requested, "media_id": media_id},
    }
