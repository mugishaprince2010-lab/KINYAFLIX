import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8000';

function App() {
  const [file, setFile] = useState(null), [rights, setRights] = useState(false);
  const [status, setStatus] = useState(''), [media, setMedia] = useState(null);
  const [job, setJob] = useState(null), [busy, setBusy] = useState(false);
  async function uploadAndTranslate() {
    if (!file || !rights) return;
    setBusy(true); setStatus('Uploading authorized media…'); setJob(null);
    try {
      const form = new FormData(); form.append('file', file); form.append('rights_confirmed', 'true');
      const r = await fetch(`${API}/api/media`, {method:'POST', body:form});
      const m = await r.json(); if (!r.ok) throw new Error(m.detail || 'Upload failed');
      setMedia(m); setStatus('Creating translation job…');
      const jr = await fetch(`${API}/api/jobs`, {method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({media_id:m.media_id,target_language:'rw',output_subtitles:true,output_dubbing:true})});
      const j = await jr.json(); if (!jr.ok) throw new Error(j.detail || 'Could not create job');
      setJob(j); setStatus(j.status === 'not_configured' ? 'Upload succeeded. AI models are not configured; no translation was generated.' : `Job status: ${j.status}`);
    } catch(e) { setStatus(`Error: ${e.message}`); } finally { setBusy(false); }
  }
  return <main className="shell">
    <header className="top"><div className="brand"><span className="logo">K</span><div><b>KinyaFlix AI</b><small>FILMS. YOUR LANGUAGE.</small></div></div><span className="pill">AI • RW</span></header>
    <section className="hero"><div className="eyebrow">FILIMI MU KINYARWANDA</div><h1>Inkuru zose,<br/><em>mu rurimi rwawe.</em></h1><p>Prepare authorized videos for Kinyarwanda subtitles and, after a compatible voice model is configured, dubbed audio.</p><div className="chips"><span>✦ Subtitles</span><span>♫ AI dubbing</span><span>⇩ Offline-ready design</span></div></section>
    <section className="panel"><div className="section-title"><div><small>START HERE</small><h2>Translate a video</h2></div><span className="number">01</span></div>
      <label className="drop"><input type="file" accept="video/*,audio/*,.mkv" onChange={e=>{setFile(e.target.files?.[0]||null);setStatus('');setMedia(null);setJob(null)}}/><span className="upload-icon">↑</span><b>{file ? file.name : 'Choose a video or audio file'}</b><small>{file ? `${(file.size/1024/1024).toFixed(1)} MB selected` : 'MP4, MOV, MKV, WebM, MP3, WAV • 1 GB dev limit'}</small></label>
      <label className="check"><input type="checkbox" checked={rights} onChange={e=>setRights(e.target.checked)}/><span>I own this media or have permission to process it.</span></label>
      <button disabled={!file || !rights || busy} onClick={uploadAndTranslate}>{busy ? 'Working…' : 'Upload & prepare translation'} <span>→</span></button>
      {status && <div className="status" role="status">{status}</div>}
      {media && <div className="result"><b>Media received</b><code>{media.media_id}</code><small>Stored by the development backend. Do not upload private videos to an unsecured server.</small></div>}
      {job && <div className="result"><b>Job: {job.status}</b><p>{job.message}</p><small>Requested outputs: {job.outputs?.requested?.join(', ') || 'none'}</small></div>}
    </section>
    <section className="features"><article><span>01 / READ</span><h3>Kinyarwanda subtitles</h3><p>Designed for timed subtitles plus a review and correction workflow.</p></article><article><span>02 / LISTEN</span><h3>Dubbed dialogue</h3><p>Requires a compatible Kinyarwanda TTS model; this starter generates no synthetic audio.</p></article><article><span>03 / OFFLINE</span><h3>Keep watching</h3><p>Designed for authorized downloads and completed subtitle/audio assets.</p></article></section>
    <footer>Prototype • No catalogue or AI model is bundled • Process only media you are authorized to use.</footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<App />);
